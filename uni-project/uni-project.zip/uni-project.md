# uni-project 使用手册

**uni-project 是一个专为 `uni-app` 打造的层叠样式表，让大多常用样式都依托于类名 以提高编码效率，使代码更简洁易维护。**

**注意：为了区分，本样式库已使用严格模式，所有类名以 `u-` 作为开头**

建议在生产环境中引用 `uni-project.min.css`

## 1. 标签默认样式

`page`, `view`, `scroll-view`, `input`, `textarea`, `text`, `swiper`, `swiper-item`, `image`, `navigator`, `button` 均被清除内外边距，并设置字体颜色为 `#333`，字体大小为 `28rpx`。
**值得注意的是，这里为了所有的 `view` 标签设置了 `box-sizing:border-box;` 这将意味着元素将无法通过 `padding` 属性撑开宽高，如有需要 请使用 `u-bs-cb` 来改变盒子模式。**

`navigator` 标签默认元素级别为**行内块级元素**。
`image` 标签默认元素级别为**块级元素**。
`textarea` 标签默认不可被用户改变大小，如有需要 请参照[可重设大小的元素](#19. 可重设大小的元素)恢复该标签默认行为。

## 2. 元素级别

**// 原型属性名为 `display`**

|    类名    |     描述     |     原型值     |
| :--------: | :----------: | :------------: |
|  `u-hide`  |     隐藏     |     `none`     |
| `u-block`  |   块级元素   |    `block`     |
| `u-inline` | 行内块级元素 | `inline-block` |
|  `u-line`  |   行内元素   |    `inline`    |
|  `u-flex`  |  弹性盒布局  |     `flex`     |

## 3. 媒体 object

### a. object-fit 媒体内容裁剪

**语法： `u-obj-*`**

**// 原型属性名为 `object-fit`**

|     类名     |                          描述                          |    原型值    |
| :----------: | :----------------------------------------------------: | :----------: |
| `u-obj-fill` |                 默认，拉伸充满整个元素                 |    `fill`    |
| `u-obj-cont` |                    等比例，内容缩放                    |  `contain`   |
| `u-obj-cove` |                    等比例，内容剪裁                    |   `cover`    |
| `u-obj-none` |               保留原始宽高，内容不被重置               |    `none`    |
| `u-obj-down` | 等比例，模式为 `none` 或 `contain`，取决于谁的尺寸更小 | `scale-down` |

### b. `object`&`background` `-position` 媒体与背景图片 定位

**语法：**
**1. object 媒体内容显示区域：`u-obj-ps-*`** // 原型属性名为 `object-fit`
**2. background 背景图片区域：`u-bg-ps-*`** // 原型属性名为 `object-position`

上面的 `*` 代表由两位字母组成的定位：

第一个字母：`l` 代表 左，`c` 代表 中，`r` 代表 右。

第二个字母：`t` 代表 上，`c` 代表 中，`b` 代表 下。

```
+----+----+----+
| lt | ct | rt |
+----+----+----+
| lc | cc | rc |
+----+----+----+
| lb | cb | rb |
+----+----+----+
```

**下表中 类名一栏已省略前缀 `u-obj-ps-` / `u-bg-ps-`，原型一栏已省略属性名**

| 类名 (`*`号部分) |       描述       |     原型值      |
| :--------------: | :--------------: | :-------------: |
|       `lt`       | 显示左侧上方区域 |   `left top`    |
|       `lc`       | 显示左侧中部区域 |  `left center`  |
|       `lb`       | 显示左侧下方区域 |  `left bottom`  |
|       `ct`       | 显示中部上方区域 |  `center top`   |
|       `cc`       |   显示中心区域   | `center center` |
|       `cb`       | 显示中部下方区域 | `center bottom` |
|       `rt`       | 显示右侧上方区域 |   `right top`   |
|       `rc`       | 显示右侧中部区域 | `right center`  |
|       `rb`       | 显示右侧下方区域 | `right bottom`  |

## 4. 定位相关

### a. position 元素定位模式

**语法： `u-ps-*`**

**// 原型属性名为 `position`**

|    类名    |     描述     |   原型值   |
| :--------: | :----------: | :--------: |
| `u-ps-def` |  元素默认值  |  `static`  |
|  `u-ps-r`  |   相对定位   | `relative` |
|  `u-ps-a`  |   绝对定位   | `absolute` |
|  `u-ps-f`  | 相对屏幕固定 |  `fixed`   |
|  `u-ps-s`  |   粘性定位   |  `sticky`  |

### b. position 定位位置

**语法： `u-ps-*`**

|     类名      |       描述        |                     原型键值对                     |
| :-----------: | :---------------: | :------------------------------------------------: |
|   `u-ps-t0`   |       贴顶        |                     `top: 0;`                      |
|   `u-ps-l0`   |       贴左        |                     `left: 0;`                     |
|   `u-ps-r0`   |       贴右        |                    `right: 0;`                     |
|   `u-ps-b0`   |       贴底        |                    `bottom: 0;`                    |
|  `u-ps-t50`   | 依赖顶部 垂直居中 |       `top:50%;transform:translateY(-50%);`        |
|  `u-ps-l50`   | 依赖左侧 水平居中 |       `left:50%;transform:translateX(-50%);`       |
|  `u-ps-r50`   | 依赖右侧 水平居中 |       `right:50%;transform:translateX(50%);`       |
|  `u-ps-b50`   | 依赖底部 垂直居中 |      `bottom:50%;transform:translateY(50%);`       |
| `u-ps-center` |   垂直水平居中    | `top:50%;left:50%;transform:translate(-50%,-50%);` |
|  `u-ps-full`  |   填充 充满元素   |          `top:0;left:0;right:0;bottom:0;`          |

## 5. 文字相关

### a. 书写模式

**语法： `u-wm-*-*`**

**// 原型属性名为 `writing-mode`**

|    类名     |                   描述                   |     原型值      |
| :---------: | :--------------------------------------: | :-------------: |
| `u-wm-h-tb` |        水平方向自上而下的书写方式        | `horizontal-tb` |
| `u-wm-v-lr` | 垂直方向内内容从上到下，水平方向从左到右 |  `vertical-lr`  |
| `u-wm-v-rl` |        垂直方向自右而左的书写方式        |  `vertical-rl`  |
| `u-wm-s-lr` |         内容垂直方向从下到上排列         |  `sideways-lr`  |
| `u-wm-s-rl` |         内容垂直方向从上到下排列         |  `sideways-rl`  |

**注意：实战中可能仅 `u-wm-v-*` 系列的可以达到自上而下的排列效果，别的不生效**

### b. 文字宽度

**语法： `u-f-b`, `u-fw-*`**

常用：`u-f-b` 常规加粗

**// 原型属性名为 `font-weight`**

|    类名    |     描述     | 原型值 |
| :--------: | :----------: | :----: |
|  `u-f-b`   |   常规加粗   | `bold` |
| `u-fw-100` | 粗细设为 100 | `100`  |
| `u-fw-200` | 粗细设为 200 | `200`  |
| `u-fw-300` | 粗细设为 300 | `300`  |
| `u-fw-400` | 粗细设为 400 | `400`  |
| `u-fw-500` | 粗细设为 500 | `500`  |
| `u-fw-600` | 粗细设为 600 | `600`  |
| `u-fw-700` | 粗细设为 700 | `700`  |
| `u-fw-800` | 粗细设为 800 | `800`  |
| `u-fw-900` | 粗细设为 900 | `900`  |

**注意：在基于 Chrome 内核浏览器的 H5 页面上， `u-fw-*` 部分数值可能达到预期效果**

### c. 文字划线

**语法： `u-td-*`**

常用：`u-t-del` 文字删除线

**// 原型属性名为 `text-decoration`**

|        类名         |    描述     |     原型值     |
| :-----------------: | :---------: | :------------: |
|     `u-td-none`     | 默认 无划线 |     `none`     |
|      `u-td-t`       |  顶部划线   |   `overline`   |
|      `u-td-b`       |  底部划线   |  `underline`   |
| `u-td-c`, `u-t-del` |   删除线    | `line-through` |

### d. 水平对齐方式

**语法： `u-t-*`**

**// 原型属性名为 `text-align`**

|  类名   |     描述      |  原型值  |
| :-----: | :-----------: | :------: |
| `u-t-l` | 默认 水平居左 |  `left`  |
| `u-t-c` |   水平居中    | `center` |
| `u-t-r` |   水平居右    | `right`  |

### e. 垂直对齐方式（即将废弃）

**注意：不建议使用，请尽量使用 `flex` 布局！**

**语法： `u-v-*`，需要定义在父级**

**// 原型属性名为 `vertical-align`**

|  类名   |   描述   |  原型值  |
| :-----: | :------: | :------: |
| `u-v-m` | 垂直居中 | `middle` |
| `u-v-t` | 垂直居上 |  `top`   |
| `u-v-b` | 垂直居下 | `bottom` |

### f. 字体大小

**语法： `u-f-*rp`**

**// 原型属性名为 `font-size`**

\*：1 ~ 80 范围内的任意**整数**，代表字体大小，单位为 `rpx`，将超出部分使用 `…` 进行省略

### g. 最大行数（自动打点）

**语法：**
**声明(必要) `u-t-elp` , `u-t-hide`**;
**使用(第一种声明模式必要) `u-t-elp-*`**

声明：规定文本溢出规则。`u-t-elp` 需要与 `u-t-elp-*` 并用 以声明在多少行后省略， `u-t-hide` 则以常规文本流(父元素高度)规则进行判断 将超出部分省略。因此 `u-t-hide` 不需要与 `u-t-elp-*` 并用。

**// "声明" 为复合样式**
**// "使用" 的原型属性名为 `line-clamp` (`-webkit-line-clamp`)**

\*：1 ~ 10 范围内的任意**整数**，代表行数限制。

### h. 换行模式

|      类名      |                 描述                  |        原型键值对        |
| :------------: | :-----------------------------------: | :----------------------: |
|  `u-t-break`   |               贪婪折行                |   相当于下面两者的组合   |
| `u-wrap-break` | 允许长单词换行 默认保持单词独立且完成 | `word-wrap: break-word;` |
| `u-break-all`  |        允许长单词折行 打破独立        | `word-break: break-all;` |

word-wrap 用于决定允不允许单词内断句。若不允许，则长单词会溢出。若允许，则先换至下一行，若下一行宽度依然不够 再进行单词内的折行。尽可能保持单词完整和可读性

word-break 贪婪换行，不同于前者的 "先换至下一行"，而是直接折行，更节省空间。

### i. 文字颜色

**语法： `u-t-*`**

**// 原型属性名为 `color`**

\*：代表常用颜色色值，具体可参照[常用颜色表](#color)

Eg:

```html
<view class="u-t-333">
  <!-- 字体颜色已被设置为 #333333 -->
</view>
```

### j. 文字间距

**语法： `u-ls-*rp`**

**// 原型属性名为 `letter-spacing`**

\*：1 ~ 20 范围内的任意整数，代表字间距大小，单位为 `rpx`

1. `u-ls-0` 即零字间距，不用写 `rp`
2. `u-ls-def` 为默认字间距

### k. 行间距

**语法： `u-lh-*`**

**// 原型属性名为 `line-height`**

\*：1 ~ 3 范围内**最多一位小数**的数字，代表行间距大小，单位为 "倍数"

**注意：因 CSS 类名内不允许使用 `.` 故用 `_` 来代替**
Eg: `u-lh-1_2` 即 1.2 倍行高

1. `u-ls-0` 即零行间距，0 ~ 1 的中间值不支持
2. `u-lh-def` 为默认行间距

## 6. 元素内容溢出处理

**语法： `u-of-*`**

**// 原型属性名为 `overflow(-x/-y)`**

|      类名       |          描述          |      原型键值对       |
| :-------------: | :--------------------: | :-------------------: |
|   `u-of-def`    |  默认 元素内容可溢出   | `overflow: visible;`  |
|   `u-of-auto`   | 内容溢出部分 正常/滚动 |   `overflow: auto;`   |
|  `u-of-x-auto`  | 横向溢出部分 正常/滚动 |  `overflow-x: auto;`  |
|  `u-of-y-auto`  | 纵向溢出部分 正常/滚动 |  `overflow-y: auto;`  |
|   `u-of-hide`   |    内容溢出部分隐藏    |  `overflow: hidden;`  |
|  `u-of-x-hide`  |    横向溢出部分隐藏    | `overflow-x: hidden;` |
|  `u-of-y-hide`  |    纵向溢出部分隐藏    | `overflow-y: hidden;` |
|  `u-of-scroll`  | 内容溢出部分使用滚动条 |  `overflow: scroll;`  |
| `u-of-x-scroll` | 横向溢出部分使用滚动条 | `overflow-x: scroll;` |
| `u-of-y-scroll` | 纵向溢出部分使用滚动条 | `overflow-y: scroll;` |

## 7. float（不建议使用）

**注意：要先在父元素声明元素内将使用浮动布局 `u-fl-cb`**

**语法： `u-fl-*`**

**// 原型属性名为 `float`**

|   类名    |              描述              |   原型键值对    |
| :-------: | :----------------------------: | :-------------: |
| `u-fl-cb` | 使用伪类清除浮动对父元素的影响 | `clear: both;`  |
| `u-fl-l`  |             左浮动             | `float: left;`  |
| `u-fl-r`  |             右浮动             | `float: right;` |

## 8. 宽度

**语法： `u-w-*`**

**// 原型属性名为 `width`**

### a. 使用内容宽度

|   类名    |       描述       |    原型值     |
| :-------: | :--------------: | :-----------: |
| `u-w-min` | 使用最小内容宽度 | `min-content` |
| `u-w-fit` | 根据内容切割宽度 | `fit-content` |
| `u-w-max` | 使用最大内容宽度 | `max-content` |

### b. 百分比宽度

相对于父级的宽度

语法： `u-w-1` ~ `u-w-100`，数字为 1 ~ 100 范围内的整数，单位为 `%`

### c. rpx 宽度

语法： `u-w-1rp` ~ `u-w-750rp`，数字为 1 ~ 750 范围内的整数，单位为 `rpx`

### d. 相对于屏幕 vw 宽度

相对于屏幕宽度的宽度

语法： `u-w-1vw` ~ `u-w-100vw`，数字为 1 ~ 100 范围内的整数，单位为 `vw`

注： `1vw === 7.5rpx`

## 9. 高度

**语法： `u-h-*`**

**// 原型属性名为 `height`**

### a. 使用内容高度

|   类名    |       描述       |    原型值     |
| :-------: | :--------------: | :-----------: |
| `u-h-min` | 使用最小内容高度 | `min-content` |
| `u-h-fit` | 根据内容切割高度 | `fit-content` |
| `u-h-max` | 使用最大内容高度 | `max-content` |

### b. vw 高度

相对于屏幕宽度的高度

语法： `u-h-1vw` ~ `u-h-100vw`，数字为 1 ~ 100 范围内的整数，单位为 `vw`

### c. 百分比高度

相对于父级的高度，前提是**父级定义了高度！**

语法： `u-h-1` ~ `u-h-100`，数字为 1 ~ 100 范围内的整数，单位为 `%`

### d. 相对于屏幕 vh 高度

相对于屏幕高度的高度

语法： `u-h-1vh` ~ `u-h-100vh`，数字为 1 ~ 100 范围内的整数，单位为 `vh`

### e. rpx 高度

语法：

1. `u-h-1rp` ~ `u-h-20rp`，数字为 1 ~ 20 范围内的整数，单位为 `rpx`
2. `u-h-20rp` ~ `u-h-200rp`，数字为 20 ~ 200 范围内，以 5 倍增的整数，单位为 `rpx`

## 10. 盒模型

### a. 内边距 padding

**语法：**

|     类名      |    描述    |             原型键值对              |
| :-----------: | :--------: | :---------------------------------: |
|  `u-pd-*rp`   | 四周内边距 |          `padding: *rpx;`           |
| `u-pd-l-*rp`  | 左方内边距 |        `padding-left: *rpx;`        |
| `u-pd-r-*rp`  | 右方内边距 |       `padding-right: *rpx;`        |
| `u-pd-t-*rp`  | 上方内边距 |        `padding-top: *rpx;`         |
| `u-pd-b-*rp`  | 下方内边距 |       `padding-bottom: *rpx;`       |
| `u-pd-lr-*rp` | 左右内边距 | `u-pd-l-*rp` 与 `u-pd-r-*rp` 的组合 |
| `u-pd-tb-*rp` | 上下内边距 | `u-pd-t-*rp` 与 `u-pd-b-*rp` 的组合 |

\*：0 ~ 80 范围内的任意**整数**，代表边距大小，单位为 `rpx`

特殊：`auto` 为自动

### b. 外边距 margin

**语法：**

|     类名      |    描述    |                原型                 |
| :-----------: | :--------: | :---------------------------------: |
|  `u-mg-*rp`   | 四周外边距 |           `margin: *rpx;`           |
| `u-mg-l-*rp`  | 左方外边距 |        `margin-left: *rpx;`         |
| `u-mg-r-*rp`  | 右方外边距 |        `margin-right: *rpx;`        |
| `u-mg-t-*rp`  | 上方外边距 |         `margin-top: *rpx;`         |
| `u-mg-b-*rp`  | 下方外边距 |       `margin-bottom: *rpx;`        |
| `u-mg-lr-*rp` | 左右外边距 | `u-mg-l-*rp` 与 `u-mg-r-*rp` 的组合 |
| `u-mg-tb-*rp` | 上下外边距 | `u-mg-t-*rp` 与 `u-mg-b-*rp` 的组合 |

\*：0 ~ 80 范围内的任意**整数**，代表边距大小，单位为 `rpx`

特殊：`auto` 为自动，如 `u-mg-lr-auto` 可以使元素相对父级 通过外边距水平居中

## 11. flex 布局

**语法： 声明弹性盒 `u-flex` , 声明内联弹性盒 `u-flex-inline`**

**// 原型语法： `display: flex;` / `display: inline-flex;`**

**注意：使用前一定要先声明！**

### a. 相对占用比

**语法： `u-flex-*`**

**注意：需要现在父级定义 `u-flex` 或 `u-flex-inline`**

**// 原型属性名为 `flex`**

\*：1 ~ 12 范围内的任意**整数**，代表元素相对占用比

例如：A 元素下有 x、y、z 三个元素。
`A.u-flex`，`x.u-flex-1`，`y.u-flex-2`，`y.u-flex-3`。
∵ 1+2+3===6
∴ x、y、z 三个元素将 A 元素等比分成了 6 份，且 x 占 1 份，y 占 2 份，z 占 3 份。

### b. 子元素布局方向

**语法： `u-flex-d-*`**

**// 原型属性名为 `flex-direction`**

|     类名      |       描述       |      原型值      |
| :-----------: | :--------------: | :--------------: |
| `u-flex-d-r`  | 默认 行布局 正序 |      `row`       |
| `u-flex-d-rr` |   行布局 倒序    |  `row-reverse`   |
| `u-flex-d-c`  |   列布局 正序    |     `column`     |
| `u-flex-d-cr` |   列布局 倒序    | `column-reverse` |

### c. 子元素换行规则

**语法： `u-flex-w-*`**

**// 原型属性名为 `flex-wrap`**

|     类名      |          描述          |     原型值     |
| :-----------: | :--------------------: | :------------: |
| `u-flex-w-nw` | 默认 子元素压缩不换行  |    `nowrap`    |
| `u-flex-w-w`  |     子元素可以换行     |     `wrap`     |
| `u-flex-w-wr` | 子元素可以换行(反方向) | `wrap-reverse` |

### d. 子元素布局及换行规则

**语法： `u-flex-f-*`**

此类名为 `u-flex-d-*` 与 `u-flex-w-*` 的复合

**// 原型属性名为 `flex-flow`**

此属性为 `flex-direction` 与 `flex-wrap` 的复合

|       类名       | 描述 (对于子元素)  |            原型值             |
| :--------------: | :----------------: | :---------------------------: |
| `u-flex-f-r-nw`  | 默认 行正序 不换行 |         `row nowrap`          |
|  `u-flex-f-r-w`  |  行正序 正序换行   |          `row wrap`           |
| `u-flex-f-r-wr`  |  行正序 倒序换行   |      `row wrap-reverse`       |
| `u-flex-f-rr-nw` |   行倒序 不换行    |     `row-reverse nowrap`      |
| `u-flex-f-rr-w`  |  行倒序 正序换行   |      `row-reverse wrap`       |
| `u-flex-f-rr-wr` |  行倒序 倒序换行   |  `row-reverse wrap-reverse`   |
| `u-flex-f-c-nw`  |   列正序 不换行    |        `column nowrap`        |
|  `u-flex-f-c-w`  |  列正序 正序换行   |         `column wrap`         |
| `u-flex-f-c-wr`  |  列正序 倒序换行   |    `column nowrap-reverse`    |
| `u-flex-f-cr-nw` |   列倒序 不换行    |    `column-reverse nowrap`    |
| `u-flex-f-cr-w`  |   列倒序 不换行    |     `column-reverse wrap`     |
| `u-flex-f-cr-wr` |   列倒序 不换行    | `column-reverse wrap-reverse` |

### e. 子元素行布局规则

**语法： `u-flex-jc-*`**

**// 原型属性名为 `justify-content`**

|      类名      |        描述 (对于子元素)        |     原型值      |
| :------------: | :-----------------------------: | :-------------: |
| `u-flex-jc-s`  |     默认 从行首位置开始排列     |  `flex-start`   |
| `u-flex-jc-c`  |       从行尾位置开始排列        |    `center`     |
| `u-flex-jc-e`  |           行居中排列            |   `flex-end`    |
| `u-flex-jc-sa` | 均匀排列 首个贴行首 末尾贴行尾  | `space-around`  |
| `u-flex-jc-sb` | 均匀排列 各元素横向分配空间相等 | `space-between` |
| `u-flex-jc-se` |       均匀排列 元素等间距       | `space-evenly`  |

由于 `justify-content: space-evenly;` 对 ios 和部分 mini Program 的兼容性并不友好，因此这里的 `u-flex-jc-se` 采用的是 `space-between` 通过在前后方加伪类的方式实现的，如果想使用原生方法，请使用 `u-flex-jc-sb-o`。(后缀 `o` 为 original 的缩写)

### f. 子元素列布局规则

**语法： `u-flex-ai-*`**

**// 原型属性名为 `align-items`**

|      类名      |      描述 (对于子元素)       |    原型值    |
| :------------: | :--------------------------: | :----------: |
| `u-flex-ai-sc` | 默认 纵轴拉伸适应容器[^ai-1] |  `stretch`   |
| `u-flex-ai-s`  |  从列首位置开始排列[^ai-2]   | `flex-start` |
| `u-flex-ai-e`  |  从列尾位置开始排列[^ai-3]   |  `flex-end`  |
| `u-flex-ai-c`  |      列居中排列[^ai-4]       |   `center`   |
| `u-flex-ai-b`  |   按照容器基线排列[^ai-5]    |  `baseline`  |

### g. 子元素多行列布局规则

**语法： `u-flex-ac-*`**

**注意：仅在多行布局下生效**

**// 原型属性名为 `align-content`**

|      类名      |           描述 (对于子元素)            |     原型值      |
| :------------: | :------------------------------------: | :-------------: |
| `u-flex-ac-sc` |      默认 纵轴拉伸适应容器[^ac-1]      |    `stretch`    |
| `u-flex-ac-s`  |       从列首位置开始排列[^ac-2]        |  `flex-start`   |
| `u-flex-ac-e`  |       从列尾位置开始排列[^ac-3]        |   `flex-end`    |
| `u-flex-ac-c`  |           列居中排列[^ac-4]            |    `center`     |
| `u-flex-ac-sa` | 均匀排列 首个贴行首 末尾贴行尾[^ac-5]  | `space-around`  |
| `u-flex-ac-sb` | 均匀排列 各元素纵向分配空间相等[^ac-6] | `space-between` |

### h. 本元素多行列布局规则

**语法： `u-flex-as-*`**

**注意: `u-flex-as-*` 会重写容器的 `u-flex-ai-*` 属性**

**// 原型属性名为 `align-self`**

|      类名      |              描述               |    原型值    |
| :------------: | :-----------------------------: | :----------: |
| `u-flex-as-a`  | 默认 继承父元素的 `u-flex-ai-*` |  `stretch`   |
| `u-flex-as-sc` |   元素被拉伸以适应容器[^as-1]   |  `flex-end`  |
| `u-flex-as-s`  |    元素位于容器的开头[^as-2]    | `flex-start` |
| `u-flex-as-e`  |    元素位于容器的结尾[^as-3]    |  `flex-end`  |
| `u-flex-as-c`  |    元素位于容器的中心[^as-4]    |  `flex-end`  |
| `u-flex-as-b`  |   元素位于容器的基线上[^as-5]   |  `flex-end`  |

### i. 弹性盒伸缩基准值

**语法： `u-flex-basis-*`**

**// 原型属性名为 `flex-basis`**

\*：1 ~ 20 范围内，以 5 倍增的整数，代表弹性盒元素的初始长度，单位为 `%`

### j. 弹性盒栅格化布局

**语法： `u-col-*`**

此功能类似于 `bootstrap` 中的栅格化布局。不同之处在于 `bootstrap` 采用的是浮动布局，与 uni-app 可能存在兼容性问题；**而本样式库是以 `flex` 弹性盒布局为基础实现的，因此也避免了因浮动而导致的高度坍塌问题**

\*：1 ~ 12 范围内的整数，代表**该元素**占用容器的份数 (\*/12)

栅格化：即将一个容器宽度**平均**分成配为 12 份，同层级的子元素基于上一级父元素宽度占用份数，换言之 12 即 100%，6 即 50%。
使用说明：需要现在父容器定义了一个栅格，子容器才可以使用栅格，而孙容器的栅格是在子容器上**自动定义**的，**无需任何操作**。

Eg:

```html
<!-- 使用栅格严格声明 -->
<view class="u-col-12">
  <!-- 2 + 8 + 2 === 12 // 整体占用父容器100% -->
  <view class="u-col-2"></view>
  <view class="u-col-8">
    <!-- 4 + 4 + 4 === 12 // 整体占用父容器100% -->
    <view class="u-col-4"></view>
    <view class="u-col-4"></view>
    <view class="u-col-4"></view>
  </view>
  <view class="u-col-2"></view>
</view>

<!-- 使用栅格自定义声明 -->
<view class="u-col" style="width:80%;">
  <!-- 2 + 8 + 2 === 12 // 整体占用父容器100% -->
  <view class="u-col-2"></view>
  <view class="u-col-8">
    <!-- 4 + 4 + 4 === 12 // 整体占用父容器100% -->
    <view class="u-col-4"></view>
    <view class="u-col-4"></view>
    <view class="u-col-4"></view>
  </view>
  <view class="u-col-2"></view>
</view>
<!-- 使用 u-col 进行声明，可以自定义容器宽度 -->
```

## 12. 边框相关

### a. 常用边框（默认 宽度 1rpx 直线样式）

**语法： `u-bd-*`**

**// 原型属性名为 `border`**

|    类名     |   描述   |           原型键值对            |
| :---------: | :------: | :-----------------------------: |
|  `u-bd-*`   | 四周边框 |     `border:1rpx solid ~;`      |
| `u-bd-l-*`  | 左方边框 |   `border-left:1rpx solid ~;`   |
| `u-bd-r-*`  | 右方边框 |  `border-right:1rpx solid ~;`   |
| `u-bd-t-*`  | 上方边框 |   `border-top:1rpx solid ~;`    |
| `u-bd-b-*`  | 下方边框 |  `border-bottom:1rpx solid ~;`  |
| `u-bd-lr-*` | 左右边框 | `u-bd-l-*` 与 `u-bd-r-*` 的组合 |
| `u-bd-tb-*` | 上下边框 | `u-bd-t-*` 与 `u-bd-b-*` 的组合 |

\*：代表常用颜色色值，具体可参照[常用颜色表](#color)

### b. 边框样式

**语法： `u-bd-*`**

**// 原型属性名为 `border-style`**

|    类名    |     描述     |        原型键值对         |
| :--------: | :----------: | :-----------------------: |
|  `u-bd-*`  | 四周边框样式 |    `border-style: *;`     |
| `u-bd-l-*` | 左方边框样式 |  `border-left-style: *;`  |
| `u-bd-r-*` | 右方边框样式 | `border-right-style: *;`  |
| `u-bd-t-*` | 上方边框样式 |  `border-top-style: *;`   |
| `u-bd-b-*` | 下方边框样式 | `border-bottom-style: *;` |

\*：代表线条类型，具体参照下表

| 类名中的\* (也是原型值) |            描述            |
| :---------------------: | :------------------------: |
|         `none`          |         定义无边框         |
|        `hidden`         |      同 `none`[^bd-1]      |
|         `solid`         |          定义实线          |
|        `dashed`         |      定义虚线[^bd-2]       |
|        `dotted`         |    定义点状边框[^bd-2]     |
|        `double`         |      定义双线[^bd-3]       |
|        `groove`         |  定义 3D 凹槽边框[^bd-4]   |
|         `ridge`         |  定义 3D 垄状边框[^bd-4]   |
|         `inset`         | 定义 3D inset 边框[^bd-4]  |
|        `outset`         | 定义 3D outset 边框[^bd-4] |

### c. 边框宽度

**语法： `u-bd-*`**

**// 原型属性名为 `border-width`**

|     类名      |     描述     |           原型键值对            |
| :-----------: | :----------: | :-----------------------------: |
|  `u-bd-*rp`   | 四周边框宽度 |      `border-width: *rpx;`      |
| `u-bd-l-*rp`  | 左方边框宽度 |   `border-left-width: *rpx;`    |
| `u-bd-r-*rp`  | 右方边框宽度 |   `border-right-width: *rpx;`   |
| `u-bd-t-*rp`  | 上方边框宽度 |    `border-top-width: *rpx;`    |
| `u-bd-b-*rp`  | 下方边框宽度 |  `border-bottom-width: *rpx;`   |
| `u-bd-lr-*rp` | 左右边框宽度 | `u-bd-l-*` 与 `u-bd-r-*` 的组合 |
| `u-bd-tb-*rp` | 上下边框宽度 | `u-bd-t-*` 与 `u-bd-b-*` 的组合 |

\*：1 ~ 10 范围内的整数，代表边框宽度，单位为 `rpx`

## 13. 关于圆角

**语法： `u-radius-*`**

**// 原型属性名为 `border-radius`**

|       类名        |   描述   |             原型键值对              |
| :---------------: | :------: | :---------------------------------: |
|  `u-radius-*rp`   | 四角圆角 |       `border-radius: *rpx;`        |
| `u-radius-tl-*rp` | 左上圆角 |   `border-top-left-radius: *rpx;`   |
| `u-radius-tr-*rp` | 右上圆角 |  `border-top-right-radius: *rpx;`   |
| `u-radius-bl-*rp` | 左下圆角 | `border-bottom-left-radius: *rpx;`  |
| `u-radius-br-*rp` | 右下圆角 | `border-bottom-right-radius: *rpx;` |

\*：1 ~ 40 范围内的整数，代表圆角大小，单位为 `rpx`

**特殊：**

1. 圆形：`u-radius-50`，前提是**对象元素为正方形**
2. 胶囊：`u-radius-cap`

## 14. 背景颜色

**语法： `u-bg-*`**

**// 原型属性名为 `background-color`**

\*：代表常用颜色色值，具体可参照[常用颜色表](#color)

## 15. 箭头

**声明： `u-arrow`**

**注意：使用前一定要先声明！**

- 该属性的实现方式是伪类
- 该属性支持动画，可以配合 [`u-animate`](#a. 动画) 使用，如：动态操作箭头方向

### a. 箭头方向

|    类名     |    描述    |             详情             |
| :---------: | :--------: | :--------------------------: |
| `u-arrow-l` | 向左的箭头 | `transform: rotate(-45deg)`  |
| `u-arrow-r` | 向右的箭头 | `transform: rotate(135deg)`  |
| `u-arrow-t` | 向上的箭头 |  `transform: rotate(45deg)`  |
| `u-arrow-b` | 向下的箭头 | `transform: rotate(-135deg)` |

### b. 箭头大小

|      类名       |    描述    |     详情     |
| :-------------: | :--------: | :----------: |
| `u-arrow-small` | 向左的箭头 | 线长 `6rpx`  |
|  `u-arrow-big`  | 向右的箭头 | 线长 `13rpx` |

### c. 箭头颜色

**语法： `u-arrow-*`**

\*：代表常用颜色色值，具体可参照[常用颜色表](#color)

### d. 页面自定义箭头

```html
<style>
  /* 创建新箭头类名（推荐） */
  .u-arrow:after.myArrow:after {
    /* 线 长度 */
    width: 12rpx;
    height: 12rpx;
    /* 线 样式/宽度/颜色 */
    border-left: solid 1rpx #666;
    border-top: solid 1rpx #666;
  }

  /* 直接改变 *声明* 根类名（此操作会在当前页面改变 *默认样式*） */
  .u-arrow:after {
    /* 线 长度 */
    width: 12rpx;
    height: 12rpx;
    /* 线 样式/宽度/颜色 */
    border-left: solid 1rpx #666;
    border-top: solid 1rpx #666;
  }
</style>
```

## 16. 按钮相关

**声明： `u-btn`**

**语法： `u-btn-*`**

\*：代表常用颜色色值，具体可参照[常用颜色表](#color)

**注意：使用前一定要先声明！**

**特殊：`u-btn-r`，可以让按钮 <u>背景色</u> 与 <u>字体和边框色</u> 反转，但仅限于本样式库支持的颜色，具体可参照[常用颜色表](#color)**

## 17. 层级表

**语法： `u-z-*`**

**// 原型属性名为 `z-index`**

**注意：此属性需要配合 [`u-ps-*`](#a. position 元素定位模式) 使用**

|    类名     |     层级     |           描述            |
| :---------: | :----------: | :-----------------------: |
| `u-z-hide`  |     `-1`     |    使元素尽可能被盖住     |
|  `u-z-def`  |     `0`      | 使元素采用默认层级[^z-1]  |
|  `u-z-min`  |     `10`     |             -             |
|  `u-z-low`  |    `100`     |             -             |
|  `u-z-mid`  |    `300`     |             -             |
| `u-z-high`  |    `500`     |             -             |
|  `u-z-max`  |    `1000`    |             -             |
| `u-z-plus`  |    `3000`    |             -             |
| `u-z-ultra` |   `10000`    |             -             |
|  `u-z-ex`   | `2147483647` | 使用 `z-index` 的上限峰值 |

## 18. 盒模型规则

**语法： `u-bs-*`**

**// 原型属性名为 `box-sizing`**

|   类名    |                            描述                            |    原型值     |
| :-------: | :--------------------------------------------------------: | :-----------: |
| `u-bs-bb` | 本样式库默认 边框盒：内边距与边框将包含在元素面积中[^bs-1] | `border-box`  |
| `u-bs-cb` | 内容盒：使用内容宽度，内边距与边框将占用额外的面积[^bs-2]  | `content-box` |

## 19. 可重设大小的元素

**语法： `u-resize-*`**

**// 原型属性名为 `resize`**

|      类名       |      描述      |    原型值    |
| :-------------: | :------------: | :----------: |
|   `u-resize`    |  支持宽高重设  |    `both`    |
|  `u-resize-w`   |  支持宽度重设  | `horizontal` |
|  `u-resize-h`   |  支持高度重设  |  `vertical`  |
| `u-resize-none` | 不支持宽高重设 |    `none`    |

## 20. 杂项

### a. 动画

**语法： `u-animate`**

**// 原型属性键值对：`transition: all .3s;`**

### b. 蒙版

**语法： `u-mask`**

**// 原型属性键值对：`background: rgba(0, 0, 0, .6);`**

### c. 阴影

**语法： `u-box-shadow`**

**// 原型属性键值对：`box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);`**

# 附件

## color

|  颜色   |   原型    |                        预览                         |
| :-----: | :-------: | :-------------------------------------------------: |
|   333   | `#333333` |  <span style="font-size:36px;color:#333">■</span>   |
|   666   | `#666666` |  <span style="font-size:36px;color:#666">■</span>   |
|   999   | `#999999` |  <span style="font-size:36px;color:#999">■</span>   |
|   e5e   | `#e5e5e5` | <span style="font-size:36px;color:#e5e5e5">■</span> |
|   f4f   | `#f4f4f4` | <span style="font-size:36px;color:#f4f4f4">■</span> |
|  white  | `#ffffff` |  <span style="font-size:36px;color:#fff">■</span>   |
|   red   | `#ff0000` |   <span style="font-size:36px;color:red">■</span>   |
|   org   | `#ff8400` | <span style="font-size:36px;color:#ff8400">■</span> |
|  green  | `#008000` |  <span style="font-size:36px;color:green">■</span>  |
|  blue   | `#0000ff` |  <span style="font-size:36px;color:blue">■</span>   |
|  grey   | `#cccccc` |  <span style="font-size:36px;color:#ccc">■</span>   |
| default | `#666666` |  <span style="font-size:36px;color:#666">■</span>   |
| primary | `#337ab7` | <span style="font-size:36px;color:#337ab7">■</span> |
|  info   | `#5bc0de` | <span style="font-size:36px;color:#5bc0de">■</span> |
| success | `#44cb7f` | <span style="font-size:36px;color:#44cb7f">■</span> |
| warning | `#ff8400` | <span style="font-size:36px;color:#ff8400">■</span> |
| danger  | `#fe6270` | <span style="font-size:36px;color:#fe6270">■</span> |

## 脚注

[^ai-1]: 如果指定侧轴大小的属性值为'auto'，则其值会使项目的边距盒的尺寸尽可能接近所在行的尺寸，但同时会遵照'min/max-width/height'属性的限制。
[^ai-2]: 弹性盒子元素的侧轴（纵轴）起始位置的边界紧靠住该行的侧轴起始边界。
[^ai-3]: 弹性盒子元素的侧轴（纵轴）起始位置的边界紧靠住该行的侧轴结束边界。
[^ai-4]: 弹性盒子元素在该行的侧轴（纵轴）上居中放置。（如果该行的尺寸小于弹性盒子元素的尺寸，则会向两个方向溢出相同的长度）。
[^ai-5]: 如弹性盒子元素的行内轴与侧轴为同一条，则该值与'flex-start'等效。其它情况下，该值将参与基线对齐。
[^ac-1]: 各行将会伸展以占用剩余的空间。如果剩余的空间是负数，该值等效于'flex-start'。在其它情况下，剩余空间被所有行平分，以扩大它们的侧轴尺寸。
[^ac-2]: 各行向弹性盒容器的起始位置堆叠。弹性盒容器中第一行的侧轴起始边界紧靠住该弹性盒容器的侧轴起始边界，之后的每一行都紧靠住前面一行。
[^ac-3]: 各行向弹性盒容器的结束位置堆叠。弹性盒容器中最后一行的侧轴起结束界紧靠住该弹性盒容器的侧轴结束边界，之后的每一行都紧靠住前面一行。
[^ac-4]: 各行向弹性盒容器的中间位置堆叠。各行两两紧靠住同时在弹性盒容器中居中对齐，保持弹性盒容器的侧轴起始内容边界和第一行之间的距离与该容器的侧轴结束内容边界与第最后一行之间的距离相等。（如果剩下的空间是负数，则各行会向两个方向溢出的相等距离。）
[^ac-5]: 各行在弹性盒容器中平均分布，两端保留子元素与子元素之间间距大小的一半。如果剩余的空间是负数或弹性盒容器中只有一行，该值等效于'center'。在其它情况下，各行会按一定方式在弹性盒容器中排列，以保持两两之间的空间相等，同时第一行前面及最后一行后面的空间是其他空间的一半。
[^ac-6]: 各行在弹性盒容器中平均分布。如果剩余的空间是负数或弹性盒容器中只有一行，该值等效于'flex-start'。在其它情况下，第一行的侧轴起始边界紧靠住弹性盒容器的侧轴起始内容边界，最后一行的侧轴结束边界紧靠住弹性盒容器的侧轴结束内容边界，剩余的行则按一定方式在弹性盒窗口中排列，以保持两两之间的空间相等。
[^as-1]: 如果指定侧轴大小的属性值为'auto'，则其值会使项目的边距盒的尺寸尽可能接近所在行的尺寸，但同时会遵照'min/max-width/height'属性的限制。
[^as-2]: 弹性盒子元素的侧轴（纵轴）起始位置的边界紧靠住该行的侧轴起始边界。
[^as-3]: 弹性盒子元素的侧轴（纵轴）起始位置的边界紧靠住该行的侧轴结束边界。
[^as-4]: 弹性盒子元素在该行的侧轴（纵轴）上居中放置。（如果该行的尺寸小于弹性盒子元素的尺寸，则会向两个方向溢出相同的长度）。
[^as-5]: 如弹性盒子元素的行内轴与侧轴为同一条，则该值与'flex-start'等效。其它情况下，该值将参与基线对齐。
[^bd-1]: 对于表格，可以解决边框冲突
[^bd-2]: 浏览器不支持时，表现为实线（同`solid`）
[^bd-3]: 双线的宽度等于`border-width`的值
[^bd-4]: 其效果取决于`border-color`的值
[^z-1]: 通常而言，`input`类的大多元素层级都很高，可能导致内容穿透的问题，善用此属性可以有效避免
[^bs-1]: 边框和内边距的值将包含在 width/height 内。也就是说，如果你将一个元素的 width/height 设为 100px，那么这 100px 会包含它的 border 和 padding，内容区的实际宽度是 width/height 减去(border+padding)的值。大多数情况下，这使得我们更容易地设定一个元素的宽高。
[^bs-2]: 如果你设置一个元素的宽为 100px，那么这个元素的内容区会有 100px 宽，并且任何边框和内边距的宽度都会被增加到最后绘制出来的元素宽度中。
